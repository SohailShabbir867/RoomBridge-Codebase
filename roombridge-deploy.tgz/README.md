# RoomBridge

RoomBridge is a full-stack room rental and roommate matching platform built for reliable room discovery, communication, and booking workflows.

## Overview

- Role-based experience for seeker, owner, and admin users
- Listing creation, discovery, filtering, and management
- Booking request lifecycle between seekers and owners
- Real-time messaging with Socket.IO
- Reporting and moderation flows for safer platform usage

## Tech Stack

- MongoDB
- Express.js
- React (Vite)
- Node.js
- Tailwind CSS
- Redux Toolkit
- Socket.IO

## Technologies and Packages Used

### Backend technologies

- Runtime and API: Node.js, Express.js
- Database and ODM: MongoDB, Mongoose
- Real-time: Socket.IO
- Media handling: Multer, Cloudinary, multer-storage-cloudinary, streamifier
- Security and validation: jsonwebtoken, bcryptjs, express-validator, helmet, hpp, xss-clean, express-mongo-sanitize, express-rate-limit, cookie-parser, cors
- Utilities: dotenv, morgan, nodemailer, express-async-handler

### Backend packages

- Dependencies: bcryptjs, cloudinary, cookie-parser, cors, dotenv, express, express-async-handler, express-mongo-sanitize, express-rate-limit, express-validator, helmet, hpp, jsonwebtoken, mongoose, morgan, multer, multer-storage-cloudinary, nodemailer, socket.io, streamifier, xss-clean
- Dev dependencies: eslint, nodemon

### Frontend technologies

- UI: React, React Router
- State management: Redux Toolkit, React Redux
- Build tooling: Vite, PostCSS, Tailwind CSS
- API and networking: Axios, Socket.IO Client
- UI utilities: React Icons, React Hot Toast, React Dropzone

### Frontend packages

- Dependencies: @reduxjs/toolkit, @tailwindcss/postcss, axios, react, react-dom, react-dropzone, react-hot-toast, react-icons, react-redux, react-router-dom, redux, socket.io-client
- Dev dependencies: @eslint/js, @types/react, @types/react-dom, @vitejs/plugin-react, autoprefixer, eslint, eslint-plugin-react, eslint-plugin-react-hooks, eslint-plugin-react-refresh, globals, postcss, tailwindcss, vite

### Package source of truth

- roombridge-backend/package.json
- roombridge-frontend/package.json

## Repository Structure

- roombridge-backend: API server, business logic, database models, and scripts
- roombridge-frontend: React client, routes, pages, state management, and services

## Prerequisites

- Node.js 18+
- npm 9+
- MongoDB instance
- Cloudinary account (for media uploads)

## Environment Variables

### Backend

Create roombridge-backend/.env:

```env
PORT=5000
MONGO_URI=your_mongodb_uri
JWT_SECRET=your_jwt_secret
JWT_EXPIRE=7d
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
NODE_ENV=development
```

### Frontend

Create roombridge-frontend/.env:

```env
VITE_API_URL=http://localhost:5000
VITE_APP_NAME=RoomBridge
```

## Local Development

### 1) Install dependencies

Backend:

```bash
cd roombridge-backend
npm install
```

Frontend:

```bash
cd roombridge-frontend
npm install
```

### 2) Run development servers

Backend:

```bash
cd roombridge-backend
npm run dev
```

Frontend:

```bash
cd roombridge-frontend
npm run dev
```

## Useful Scripts

### Backend

- npm run dev: start backend with nodemon
- npm run start: start backend in production mode
- npm run lint: run ESLint
- npm run seed:admin: create or update admin account
- npm run seed:demo: seed demo users, listings, bookings, and preferences
- npm run cleanup:demo: remove seeded demo data

### Frontend

- npm run dev: start Vite development server
- npm run build: create production build
- npm run preview: preview production build
- npm run lint: run ESLint

## Quality Checks

Backend:

```bash
cd roombridge-backend
npm run lint
```

Frontend:

```bash
cd roombridge-frontend
npm run lint
npm run build
```

## Deployment

### Recommended split

- Deploy backend (Node/Express) as a web service
- Deploy frontend (Vite build output) as a static site
- Use a managed MongoDB instance for production data

### Backend deployment checklist

1. Set production environment variables on your host.
2. Set NODE_ENV=production.
3. Install dependencies and run:

```bash
npm run start
```

4. Configure CORS to allow your frontend production domain.
5. Ensure secure cookie and HTTPS settings are enabled in production.

### Frontend deployment checklist

1. Set VITE_API_URL to your deployed backend base URL.
2. Build the app:

```bash
npm run build
```

3. Deploy roombridge-frontend/dist to your static hosting provider.
4. Configure SPA fallback/rewrites so client-side routes work on refresh.

### Post-deployment verification

- Verify authentication flow (login/logout/session persistence)
- Verify listing create/read/update flows
- Verify booking and messaging flows
- Verify report submission and admin actions
- Run lint/build checks in CI before every release

## Notes

- Keep both backend and frontend running during local development.
- Use production-safe secrets for deployed environments.
- Do not commit .env files.